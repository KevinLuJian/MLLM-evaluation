This datasets is a derivative of DVQA, used in the paper.
Revisiting Multi-Modal LLM Evaluation by Jian Lu, Shikhar Srivastava, Junyu Chen, Robik Shrestha, Manoj Acharya, Kushal Kafle, Christopher Kanan.


The datasets is orginally being published by the paper: 
Kafle, K., Price, B., Cohen, S., & Kanan, C. (2018, March 29). DVQA: Understanding data visualizations via question answering. arXiv.org. https://arxiv.org/abs/1801.08163 
